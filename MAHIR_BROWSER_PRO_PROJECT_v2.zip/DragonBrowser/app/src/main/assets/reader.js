(function () {
  var old = document.getElementById('__mahir_reader');
  if (old) { old.remove(); document.documentElement.style.overflow = ''; return; }
  function score(el) {
    var n = 0, ps = el.querySelectorAll('p');
    for (var i = 0; i < ps.length; i++) { var l = (ps[i].innerText || '').length; if (l > 60) n += l; }
    return n;
  }
  var cands = Array.prototype.slice.call(document.querySelectorAll('article,main,section,div')), max = 0, i, s;
  for (i = 0; i < cands.length; i++) { s = score(cands[i]); if (s > max) max = s; }
  var best = null, bl = 1e12;
  for (i = 0; i < cands.length; i++) {
    s = score(cands[i]);
    if (max > 0 && s >= max * 0.8) {
      var len = (cands[i].textContent || '').length;
      if (len < bl) { bl = len; best = cands[i]; }
    }
  }
  var ov = document.createElement('div');
  ov.id = '__mahir_reader';
  var dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  var size = 18;
  function theme() {
    ov.style.background = dark ? '#17181b' : '#fbfbfa';
    ov.style.color = dark ? '#e6e8ec' : '#1f2125';
  }
  ov.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483647;overflow:auto;-webkit-overflow-scrolling:touch;font-family:Georgia,"Noto Serif",serif;line-height:1.7;';
  theme();
  var bar = document.createElement('div');
  bar.style.cssText = 'position:sticky;top:0;display:flex;gap:8px;justify-content:flex-end;padding:10px 12px;background:inherit;border-bottom:1px solid rgba(128,128,128,.3);font-family:system-ui,sans-serif';
  function btn(label, fn) {
    var b = document.createElement('button');
    b.textContent = label;
    b.style.cssText = 'min-width:44px;height:38px;padding:0 12px;border-radius:10px;border:1px solid rgba(128,128,128,.5);background:transparent;color:inherit;font-size:15px';
    b.onclick = fn; bar.appendChild(b);
  }
  var wrap = document.createElement('div');
  wrap.style.cssText = 'max-width:680px;margin:0 auto;padding:18px 20px 60px;font-size:' + size + 'px';
  btn('A-', function () { size = Math.max(14, size - 2); wrap.style.fontSize = size + 'px'; });
  btn('A+', function () { size = Math.min(30, size + 2); wrap.style.fontSize = size + 'px'; });
  btn('\u25D0', function () { dark = !dark; theme(); });
  btn('\u2715', function () { ov.remove(); document.documentElement.style.overflow = ''; });
  ov.appendChild(bar);
  var h = document.createElement('h1');
  h.textContent = document.title || '';
  h.style.cssText = 'font-size:1.5em;line-height:1.3;margin:12px 0 18px';
  wrap.appendChild(h);
  var count = 0;
  if (best) {
    var nodes = best.querySelectorAll('h1,h2,h3,h4,p,li,blockquote,pre,img');
    for (i = 0; i < nodes.length; i++) {
      var n = nodes[i], tag = n.tagName.toLowerCase(), skip = false, a = n.parentNode;
      while (a && a !== best) {
        if (/^(nav|aside|footer|form|header)$/i.test(a.tagName || '')) { skip = true; break; }
        a = a.parentNode;
      }
      if (skip) continue;
      var el;
      if (tag === 'img') {
        var src = n.currentSrc || n.src;
        if (!src || n.naturalWidth < 150) continue;
        el = document.createElement('img'); el.src = src;
        el.style.cssText = 'max-width:100%;height:auto;border-radius:8px;margin:12px 0;display:block';
      } else {
        var txt = (n.innerText || '').trim();
        if (!txt || (tag === 'li' && txt.length < 25)) continue;
        el = document.createElement(tag === 'li' ? 'p' : tag);
        el.textContent = tag === 'li' ? '\u2022 ' + txt : txt;
        if (tag === 'blockquote') el.style.cssText = 'border-left:3px solid rgba(128,128,128,.6);margin:12px 0;padding-left:14px;opacity:.9';
        if (tag === 'pre') el.style.cssText = 'overflow:auto;font-size:.8em;background:rgba(128,128,128,.15);padding:10px;border-radius:8px';
      }
      wrap.appendChild(el); count++;
    }
  }
  if (!count) {
    var m = document.createElement('p');
    m.textContent = 'Reader mode is not available for this page.';
    m.style.cssText = 'font-family:system-ui,sans-serif;opacity:.75';
    wrap.appendChild(m);
  }
  ov.appendChild(wrap);
  document.documentElement.appendChild(ov);
  document.documentElement.style.overflow = 'hidden';
})();
